export interface IHistoryData {
  text: string;
}
