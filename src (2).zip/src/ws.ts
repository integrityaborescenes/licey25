export const socket = new WebSocket("ws://localhost:8080");
