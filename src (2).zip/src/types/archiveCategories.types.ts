export interface IArchiveCategories {
  id: number;
  title: string;
}
